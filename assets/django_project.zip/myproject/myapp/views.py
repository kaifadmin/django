from django.shortcuts import render,redirect
from django.contrib import auth

def index(request):
    return render(request, 'index.html')

def shop(request):
    return render(request, 'shop.html')

def about(request):
    return render(request, 'about.html')

def services(request):
    return render(request, 'services.html')

def blog(request):
    return render(request, 'blog.html')

def contact(request):
    return render(request, 'contact.html')

def cart(request):
    return render(request, 'cart.html')

def checkout(request):
    return render(request, 'checkout.html')

def thankyou(request):
    return render(request, 'thankyou.html')

def login(request):
    if request.method == "POST":
        us=request.POST['username']
        ps=request.POST['password']
        user = auth.authenticate(request,username=us,password=ps)
        if user is not None:
            auth.login(request,user)
            print("login successfully")
            return redirect('index')
        else:
            print("username and password not found")
            return redirect("login")
    return render(request, 'login.html')